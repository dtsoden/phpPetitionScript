<?php 
session_start();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EDIT HOW THE EMAIL READS
// When you see an \n  it puts in a line return 
// A double \n \n puts in a carriage return


	//Subject of the mail
	$Subject = $_POST['rname']. " Please consider this petition";  

	// First Line of the Body in the email
	$Line1 = $_POST['rname'] . " I just signed this petition and thought you also could do the same? \n \n";

	// This text is provided by the visitor filling out the message box in the form
	$usermessage = $_POST['rmessage']. " \n \n";

	// This This is the line just before the link to your petition
	$Line2 =  "The link to the site where I signed this petition is below. \n \n" ;

	// CHOOSE EITHER THE DYNAMIC URL  or type your own
	$URL =  "http://" . $_SERVER['HTTP_HOST']."/".phpPETITION."/ \n \n";
	//$URL = 	"http://some_domain_name_here.com";

	$Signature = $_POST['yname'];
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

if( isset($_POST['submit'])) {
   if( $_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'] ) ) {
// Insert you code for processing the form here. 

	// Bring in the required outside files
	require_once('../Connections/petitionscript.php'); 
	require("../phpmailer/class.phpmailer.php"); 

//GET config Record Set
mysql_select_db($database_petitionscript, $petitionscript);
$query_config = "SELECT * FROM config";
$config = mysql_query($query_config, $petitionscript) or die(mysql_error());
$row_config = mysql_fetch_assoc($config);
$totalRows_config = mysql_num_rows($config);
$text = str_replace("\n.", "\n..", $text);
$mail = new PHPMailer(); //Create PHPmailer class 
$mail->From = $_POST['yemail']; //Sender address 
$mail->FromName = $_POST['yname']; //The name that you'll see as Sender
$mail->Host = $row_config['EmailServer']; //Your SMTP mail server 
$mail->AddAddress($_POST['remail']); //The address you are sending mail to 
// Uncomment below enable Blind Carbon Copy and add a proper email address
//$mail->AddBCC("*@*.com"); 
if($row_config['SMTPAuth']==1)
	{
	$mail->SMTPAuth = "true";
	$mail->Mailer = "smtp"; 
	$mail->Username = $row_config['Username'];
	$mail->Password = $row_config['Password'];
	}
elseif($row_config['SMTPAuth']==0)
	{
	$mail->SMTPAuth = "false";
	$mail->Mailer = "mail"; 
	}
$mail->Subject = $Subject;
$mail->Body = $Line1.
			  $usermessage.
			  $Line2.
			  $URL.
			  $Signature;
if(!$mail->Send()){ //Check for result of sending mail 
   echo "OOPS... There was an error sending the message"; //Write an error message if mail isn't sent 
   exit; } //Exit the script without executing the rest of the code
	
	echo "Referral Sent Successfully<br />Click <a href='".$URL."'>Here</a> to return to the petition";
	unset($_SESSION['security_code']);

   } elseif( $_SESSION['security_code'] != $_POST['security_code'] && !$_POST['security_code'] == '' ) {
		// Insert your code for showing an error message here
		echo 'Captcha entered incorrectly';
   } elseif ( $_POST['security_code'] == '' ) {
	   // Insert your code for showing an error message here
		echo 'Oops, you forgot the Captcha Code!!!';
   }
} else {
?>
<link rel="stylesheet" type="text/css" href="../phpPetitionTemplate/mm_travel2.css">
<div align="center" class="pageName">Recomend This Petition To Someone Else</div>
<form class="smallText" action="index.php" method="post">
<p align="center"><em><strong>NOTE THIS PAGE IS AN ADD-ON MODULE AND IS NOT INCLUDED WITH THE FREE SCRIPT</strong></em></p>
<table border="0" align="center" cellspacing="3">
<tr>
            <td width="150"><label for="label">Your Name: </label></td>
      <td width="200"><input type="text" name="yname" id="yname" /></td>
    </tr>
          <tr>
            <td width="150"><label for="label">Your Email: </label></td>
            <td width="200"><input type="text" name="yemail" id="yemail" /></td>
    </tr>
          <tr>
            <td width="150">Recipients Name</td>
            <td width="200"><input type="text" name="rname" id="rname" /></td>
    </tr>
          <tr>
            <td width="150">Recipients Email</td>
            <td width="200"><input type="text" name="remail" id="remail" /></td>
    </tr>
          <tr>
            <td width="150"><label for="label">Message: </label></td>
            <td width="200" class="subHeader"><?php echo $Line1 ?><br /> 
              <textarea rows="5" cols="30" name="rmessage" id="rmessage"></textarea><br />
            <?php echo $Line2 ?> <br />
			<?php echo $URL ?>
			<p></p>
            </td>
    </tr>
          <tr>
            <td width="150">Captcha Image:</td>
            <td width="200"><img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /></td>
    </tr>
          <tr>
            <td width="150"><label for="label">Captcha Code: </label></td>
            <td width="200"><input id="security_code" name="security_code" type="text" /></td>
    </tr>
          <tr>
            <td width="150">&nbsp;</td>
            <td width="200"><input type="submit" name="submit" value="Submit" /></td>
    </tr>
        </table>
  <label for="yname"><br />
  </label>
        <label for="yemail"></label>
        <label for="rmessage"></label>
		<label for="security_code"></label>
</form>
<p>
  <?php
	}
?>
