<h1><font color="#FF0000">After</font> you have setup an empty database called <font color="#FF0000">petitionscript</font><br>
    <a href="<?php echo $_SERVER['PHP_SELF'] . "?MYSQL_ID1=MYSQL_Script" ?> ">Click here</a> to begin the table and admin security setup process.</p></h1>
<p><br>
  
  
<?php
$SQL1 = "
--
-- Table structure for table `petitionscript`.`security`
--

CREATE TABLE `security` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `User` varchar(15) NOT NULL default '',
  `Password` varchar(15) NOT NULL default '',
  `AccessLevel` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`ID`)
);
";
$SQL2 = "
--
-- Table structure for table `petitionscript`.`signature`
--
CREATE TABLE `signature` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `FirstName` varchar(45) NOT NULL default '',
  `LastName` varchar(45) NOT NULL default '',
  `Email` varchar(45) NOT NULL default '',
  `TSDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `IP` varchar(45) NOT NULL default '',
  `Confirmation` tinyint(1) unsigned NOT NULL default '0',
  `radSelect` varchar(100) NOT NULL default '',
  `Class` varchar(4) NOT NULL default '',
  `txtOther` varchar(45) default NULL,
  PRIMARY KEY  (`ID`)
);
";
$SQL3 = "
--
-- Adding Security data for table `petitionscript`.`security`
--
INSERT INTO `security` (`ID`,`User`,`Password`,`AccessLevel`) VALUES 
 (18,'test','test',0),
 (19,'admin','admin',1);
";

IF
($_GET['MYSQL_ID1'] == 'MYSQL_Script') {

 require_once('Connections/petitionscript.php');
 mysql_select_db($database_petitionscript, $petitionscript);
 
	IF
		(mysql_query($SQL1))
		{
		echo "<font color='#FF9900' size='+2'>Security Table Create Was A Sucess</font><br>" .
			 "<a href='setup.php?MYSQL_ID2=MYSQL_Script'>Now setup the signature table</a>";
		} Else {
		echo "<font color='#FF0000' size='+2'>Error Creating Security Table</font>" . 
			 "<font color='#FF0000' size='+2'>". 
			  mysql_error() . 
			 "</font>" ;
		}
}

IF
($_GET['MYSQL_ID2'] == 'MYSQL_Script') {

 require_once('Connections/petitionscript.php');
 mysql_select_db($database_petitionscript, $petitionscript);
 
	IF
		(mysql_query($SQL2))
		{
		echo "<font color='#FF9900' size='+2'>The Signature Table Creeation Was A Sucess</font><br>" .
			 "<a href='setup.php?MYSQL_ID3=MYSQL_Script'>Now lets add the default security accounts</a>";
		} Else {
		echo "<font color='#FF0000' size='+2'>Error Creating Signature Table</font>" . 
			 "<font color='#FF0000' size='+2'>". 
			  mysql_error() . 
			 "</font>" ;
		}
}

IF
($_GET['MYSQL_ID3'] == 'MYSQL_Script') {

 require_once('Connections/petitionscript.php');
 mysql_select_db($database_petitionscript, $petitionscript);
 
	IF
		(mysql_query($SQL3))
		{
		echo "<font color='#FF9900' size='+2'>Default Security Accounts Setup Successful</font><br>" .
			 "<a href='index.php'>Sign Your First Petition</a>";
		} Else {
		echo "<font color='#FF0000' size='+2'>Error adding default security accounts</font>" . 
			 "<font color='#FF0000' size='+2'>". 
			  mysql_error() . 
			 "</font>" ;
		}
}  
	?>
</p>
