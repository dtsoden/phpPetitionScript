<?php
require_once('Connections/petitionscript.php');

mysql_select_db($database_petitionscript, $petitionscript);
$query_rs = "SELECT count(*) as RecordCount FROM signature";
$rs = mysql_query($query_rs, $petitionscript) or die(mysql_error() . " <a href='setup.php'>Click Here</a> to Setup the Table");
$row_rs = mysql_fetch_assoc($rs);
$totalRows_rs = mysql_num_rows($rs);

mysql_free_result($rs);
?>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
<?php echo  "&nbsp; Total Signatures to Date = " . $row_rs['RecordCount']; ?>

<form action="received.php" method="post" name="form1" onsubmit="MM_validateForm('FirstName','','R','LastName','','R','Email','','RisEmail');return document.MM_returnValue">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">FirstName:</td>
      <td><input type="text" name="FirstName" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">LastName:</td>
      <td><input type="text" name="LastName" value="" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Email:</td>
      <td><input type="text" name="Email" value="" size="32"><br />
	  <font size="-3">Use a real address if you want it to work</font></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Class</td>
      <td><input name="Class" type="text" id="Class" value="" size="4" maxlength="4" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Affiliation</td>
      <td><input name="radSelect" type="radio" id="radSelect" tabindex="1" value="Alumni" />
      Alumni<br />
      <input name="radSelect" type="radio" id="radio" tabindex="2" value="Family" />
      Family<br />
      <input name="radSelect" type="radio" id="radio2" tabindex="3" value="Friend" /> 
      Friend<br />
<input name="radSelect" type="radio" id="radio3" tabindex="4" value="Faculty" />
Faculty<br />
<input name="radSelect" type="radio" id="radio4" tabindex="5" value="Student" />
Student<br />
<input name="radSelect" type="radio" id="radio5" tabindex="6" value="Other" /> 
Other (<font size="-3">If Other, Please explain</font>)
<input name="txtOther" type="text" id="txtOther" /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="SIGN PETITION"></td>
    </tr>
  </table>
  <p>
  <input type="hidden" name="IP" value="<?php Echo $_SERVER['REMOTE_ADDR'] ?>" size="32">
  <input type="hidden" name="Date" value="<?php Echo  date('Y-m-d H:i:s') ?>" size="32">
  <input type="hidden" name="MM_insert" value="form1">
  </p>
</form>
<p>&nbsp;</p>
