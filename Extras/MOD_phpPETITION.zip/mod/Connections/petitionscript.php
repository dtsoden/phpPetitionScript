<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_petitionscript = "localhost";
$database_petitionscript = "petitionscript";
$username_petitionscript = "dtsoden";
$password_petitionscript = "atad3366";
$petitionscript = mysql_pconnect($hostname_petitionscript, $username_petitionscript, $password_petitionscript) or trigger_error(mysql_error(),E_USER_ERROR); 
?>