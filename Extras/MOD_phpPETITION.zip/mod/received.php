<?php require_once('Connections/petitionscript.php'); 

# Switch Type Function
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

# Check For Duplicate Signatures
	
	mysql_select_db($database_petitionscript, $petitionscript);

	$query_rsEmailDupChk = 'SELECT count(signature.Email) as DupChk FROM signature WHERE signature.Email = ' . GetSQLValueString($_POST['Email'], "text");

	$rsEmailDupChk = mysql_query($query_rsEmailDupChk, $petitionscript) or die(mysql_error());

	$row_rsEmailDupChk = mysql_fetch_assoc($rsEmailDupChk);

	$totalRows_rsEmailDupChk = mysql_num_rows($rsEmailDupChk);

if ($row_rsEmailDupChk['DupChk'] > 0 ) {
		echo " <center><h1> Sorry you have already signed this petition </h1></center> <br />";

# No Duplicate Signatures... Then process the Signature
} ELSE {


if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO signature (FirstName, LastName, Email, Class, radSelect, txtOther, `TSDate`, IP) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['FirstName'], "text"),
                       GetSQLValueString($_POST['LastName'], "text"),
                       GetSQLValueString($_POST['Email'], "text"),
					   GetSQLValueString($_POST['Class'], "text"),
					   GetSQLValueString($_POST['radSelect'], "text"),
					   GetSQLValueString($_POST['txtOther'], "text"),
                       GetSQLValueString($_POST['Date'], "date"),
                       GetSQLValueString($_POST['IP'], "text"));

  mysql_select_db($database_petitionscript, $petitionscript);
  $Result1 = mysql_query($insertSQL, $petitionscript) or die(mysql_error());
}
?>


<p>Your Petition Signature was received on 
  <?php 
echo date('l, F d')?> 
  at <?php echo date('g:i:s A')?><br />
  <br />
<?php echo $_POST['FirstName'] ?> , by law, for your electronic signature to count, we have to verify that you really signed and that someone did not use your email address frauduantly<br />
  <br />
We have sent you an email, please click on the link in the email to verify your signature</p>
<?php 
$text = str_replace("\n.", "\n..", $text);
$Message =  "Thanks for filling out our petition " . $_POST['FirstName']. ", your almost done! \n" .
			"Please confirm your signature by clicking on the link below \n \n" .
			"http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) .
			"/confirm.php?Email=" . urlencode($_POST['Email']) . "&FirstName=" . urlencode($_POST['FirstName']) ."\n \n" .
			"Sincerely \n".
			"You�re Petition Support Team";
$headers = 'From: webmaster@PetitionScript.com' . "\r\n" .
   		   'Reply-To: webmaster@PetitionScript.com' . "\r\n" .
		   'X-Mailer: PHP/' . phpversion() . "\r\n" .
		   'Return-Path: webmaster@PetitionScript.com' ;
		   
mail($_POST['Email'], 'Please Confirm Your Signature', $Message, $headers);

}
?>
