<h1><font color="#FF0000">UPGRADE phpPETITIONSCRIPT </font>This script will upgrade your petitionscript database schema to <font color="#FF0000">Version 2.0</font><br>
    <a href="<?php echo $_SERVER['PHP_SELF'] . "?MYSQL_ID1=MYSQL_Script" ?> ">Click here</a> to begin the table and admin security setup process.</p></h1>
<p><br>
  
  
<?php
$SQL1 = "
--
-- Table structure for table `petitionscript`.`security`
--

CREATE TABLE `security` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `User` varchar(15) NOT NULL default '',
  `Password` varchar(15) NOT NULL default '',
  `AccessLevel` int(10) unsigned NOT NULL default '1',
  PRIMARY KEY  (`ID`)
);
";
$SQL2 = "
--
-- Adding Security data for table `petitionscript`.`security`
--
INSERT INTO `security` (`ID`,`User`,`Password`,`AccessLevel`) VALUES 
 (18,'test','test',0),
 (19,'admin','admin',1);
";

IF
($_GET['MYSQL_ID1'] == 'MYSQL_Script') {

 require_once('Connections/petitionscript.php');
 mysql_select_db($database_petitionscript, $petitionscript);
 
	IF
		(mysql_query($SQL1))
		{
		echo "<font color='#FF9900' size='+2'>Security Table Create Was A Sucess</font><br>" .
			 "<a href='Upgrade_Ver1_to_V2.php?MYSQL_ID2=MYSQL_Script'>Now setup the signature table</a>";
		} Else {
		echo "<font color='#FF0000' size='+2'>Error Creating Security Table</font>" . 
			 "<font color='#FF0000' size='+2'>". 
			  mysql_error() . 
			 "</font>" ;
		}
}

IF
($_GET['MYSQL_ID2'] == 'MYSQL_Script') {

 require_once('Connections/petitionscript.php');
 mysql_select_db($database_petitionscript, $petitionscript);
 
	IF
		(mysql_query($SQL2))
		{
		echo "<font color='#FF9900' size='+2'>Default Security Accounts Setup Successful</font><br>" .
			 "<a href='index.php'>Sign Your First Petition</a>";
		} Else {
		echo "<font color='#FF0000' size='+2'>Error adding default security accounts</font>" . 
			 "<font color='#FF0000' size='+2'>". 
			  mysql_error() . 
			 "</font>" ;
		}
}  
	?>
</p>
