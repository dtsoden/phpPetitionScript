<html>
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Petition Script PHP</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="phpPetitionTemplate/mm_travel2.css" type="text/css">
<script language="javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
</head>
<body bgcolor="#C0DFFD">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3366CC">
    <td width="382" colspan="3" rowspan="2"><img src="phpPetitionTemplate/mm_travel_photo.jpg" alt="Petition Script PHP" width="382" height="127" border="0"></td>
    <td width="378" height="63" colspan="3" id="logo" valign="bottom" align="center" nowrap>Petition Script PHP  </td>
    <td width="100%">&nbsp;</td>
  </tr>

  <tr bgcolor="#3366CC">
    <td height="64" colspan="3" id="tagline" valign="top" align="center">Where Your Opinion Counts </td>
	<td width="100%">&nbsp;</td>
  </tr>

  <tr>
    <td colspan="7" bgcolor="#003366"><img src="phpPetitionTemplate/mm_spacer.gif" alt="" width="1" height="1" border="0"></td>
  </tr>

  <tr valign="middle" bgcolor="#CCFF99">
  	<td colspan="1" id="dateformat" height="25">&nbsp;&nbsp;
  	  <script language="javascript">
      document.write(TODAY);</script>	</td>
    <td colspan="5" id="dateformat" height="25" valign="middle">
	<a href="http://www.chimicon.com/petition/"><img src="../images/ASPpetition.gif" alt="Petition Script Available in ASP" border="0" align="right"></a>	</td>
	<td id="dateformat" height="25" valign="middle">
	</td>
  </tr>
 <tr>
    <td colspan="7" bgcolor="#003366"><img src="phpPetitionTemplate/mm_spacer.gif" alt="" width="1" height="1" border="0"></td>
  </tr>

 <tr>
    <td width="165" valign="top" bgcolor="#E6F3FF">
	<table border="0" cellspacing="0" cellpadding="0" width="165" id="navigation">
        <tr>
          <td width="165"><a href="index.php" class="navText">Sign Petition </a></td>
        </tr>
        <tr>
          <td width="165"><a href="results.php" class="navText">View Signatures </a></td>
        </tr>
        <tr>
          <td width="165"><a href="/phpSupport/index.php" class="navText">Support </a></td>
        </tr>
		<tr>
		<td><A HREF="http://www.scriptsearch.com">ScriptSearch.com</A></td>
		</tr>
		<tr>
		<td><A HREF="admin/">ADMIN LOGIN </A></td>
		</tr>
      </table>
 	 
 	<div align="center">&nbsp;<img src="phpPetitionTemplate/php.gif" alt="Petition Script PHP" width="123" height="110" longdesc="http://thewebsiteguru.com"><a><br>
        <a href="phpPETITION.zip">CLICK TO<br>
 	    DOWNLOAD NOW</a>
        <p><br>
 	      <a href="../CFpetition/"><img src="../images/logo_phpBB.gif" alt="Petition Script" border="0"><br>
 	      <a href="../CFpetition/default.cfm">Also Available in <br>
 	    Cold Fusion</a></p>
 	  <p class="subHeader"><br></p>
 	</div>
	<style type="text/css">
<!--
.title {
font-family: Verdana, Arial, Helvetica, sans-serif;
font-size: 18px;
font-weight: bold;
color: #FFFFFF;
text-decoration: none;
}
-->
</style>
 <table width="110" border="0" align="center" cellpadding="3" cellspacing="2" bgcolor="#CC0000"> 
   <form action="http://www.scripts.com/rate.php" method="POST"> <input type="hidden" name="ID" value="SCRIPTID"> <tr>  <td bgcolor="#FF9900"><center class="search"> <a href="http://www.scripts.com"><img src="http://images.devshed.com/scr/misc/logo_01.gif" width="45" height="28" border="0"></a>  <b><a href="http://www.scripts.com" class="title">Scripts.com</a></b>  <font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Rate  Script!</font>  <select name="rating" id="select3"> <option value="5" selected>Excellent!</option> <option value="4">Very Good</option> <option value="3">Good</option> <option value="2">Fair</option> <option value="1">Poor</option> </select> <br> <a href="#"> <input name="vote222" type="submit" id="vote22" value="Vote!"> </a> </center></td> </tr> </form></table>	</td>
    <td width="50"><img src="phpPetitionTemplate/mm_spacer.gif" alt="" width="50" height="1" border="0"></td>
    <td width="305" colspan="2" valign="top"><img src="phpPetitionTemplate/mm_spacer.gif" alt="" width="305" height="1" border="0"><br>
	&nbsp;<br>
	&nbsp;<br>
	<table border="0" cellspacing="0" cellpadding="0" width="305">
        <tr>
          <td class="pageName">Welcome To Petition Script </td>
		</tr>

		<tr>
          <td class="bodyText"><p>This Home Page layout makes a great starting point for your Petition. Virtually all of the content is customizable, including the images, the text, and the links. You can decide whether to keep the existing graphics or swap them out for pictures of your own.</p>

		    <p>The text on this page is intended to help you jumpstart your design by suggesting the sort of content you may want to include, but don't let it limit you. The same is also true for the link text - feel free to change the names of the links to better suit your particular needs. The Database and Fields can be expanded as well... Have fun and make a great Petition website! (Customizations and Installation Available; starting at US Funds $25.00 <a href="mailto:cs@thewebsiteguru.com">email</a><a href="mailto:cs@thewebsiteuru.com"></a> us for details) </p></td>
        </tr>
      </table>
	   <br>
	  <strong> 	  SIGN OUR PETITION</strong> <br>
      <?php 
#phpinfo();
include("signature.php"); 
?>    </td>
    <td width="50"><img src="phpPetitionTemplate/mm_spacer.gif" alt="" width="50" height="1" border="0"></td>
        <td width="190" valign="top"><br>
		&nbsp;<br>
		<table border="0" cellspacing="0" cellpadding="0">
			<tr>
			<td colspan="3" class="subHeader" align="center">GET SCRIPTS </td>
			</tr>
			<tr>
			<td id="sidebar" class="smallText" align="center">
			<a href="http://www.scripts.com">
			<img src="http://images.devshed.com/scr/banners/banner_160x600.gif" border=0 alt="Scripts.com">			</a>			</td>
			</tr>
		</table>		</td>
	<td width="100%">&nbsp;</td>
  </tr>
  <tr>
    <td width="165">&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="167">&nbsp;</td>
    <td width="138">&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="190">&nbsp;</td>
	<td width="100%">&nbsp;</td>
  </tr>
</table>
</body>
</html>
